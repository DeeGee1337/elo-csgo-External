//#pragma once
//
//#include <d3d11.h>
//
//
//
//namespace icons
//{
//	extern ID3D11ShaderResourceView* g_xhair;
//	extern ID3D11ShaderResourceView* g_check;
//	extern ID3D11ShaderResourceView* g_mcIcon;
//
//	void release();
//	bool create(ID3D11Device* device, ID3D11DeviceContext* deviceContext);
//}