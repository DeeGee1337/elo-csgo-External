#pragma once

namespace netvars
{
	bool initialize();

}