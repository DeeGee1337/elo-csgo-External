#include "netvars.hpp"
#include "csgo.hpp"

namespace netvars
{
	bool initialize()
	{
		return true;
	}

}